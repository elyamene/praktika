package shim;

public class NovoeName {

}
